package com.gameinfo.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/** Распознаёт текст на фото диска и выбирает вероятное название игры. */
object TitleExtractor {

    private val noise = Regex(
        "playstation|ps[ ]?[2-5]\\b|\\bps\\b|xbox|series|\\bone\\b|pegi|esrb|©|®|™|www\\.|\\.com|sony|" +
                "microsoft|rating|only on|ultra|blu-?ray|all rights|region|dolby|dualsense|kinect|" +
                "\\bx\\|s\\b|optimized|enhanced|edition|greatest hits|platinum|essentials|игра|диск|\\d{4,}",
        RegexOption.IGNORE_CASE
    )

    private data class Line(val text: String, val top: Int, val height: Int)

    /** Возвращает варианты названия, лучший первым. */
    suspend fun extract(context: Context, uri: Uri): List<String> {
        val bmp = decode(context, uri) ?: return emptyList()
        val image = InputImage.fromBitmap(bmp, 0)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val result = suspendCancellableCoroutine { cont ->
            recognizer.process(image)
                .addOnSuccessListener { cont.resume(it) }
                .addOnFailureListener { cont.resume(null) }
        }
        recognizer.close()
        result ?: return emptyList()

        val lines = result.textBlocks.flatMap { it.lines }.mapNotNull { l ->
            val box = l.boundingBox ?: return@mapNotNull null
            val t = l.text.trim().replace(Regex("[^\\p{L}\\p{N}:'&!\\- ]"), "").trim()
            val letters = t.count { it.isLetter() }
            if (letters < 3 || noise.containsMatchIn(t)) null
            else Line(t, box.top, box.height())
        }
        if (lines.isEmpty()) return emptyList()

        val sorted = lines.sortedByDescending { it.height }
        val out = LinkedHashSet<String>()

        // главный вариант: самая крупная строка + соседние строки близкого размера (название в две строки)
        val best = sorted.first()
        val group = lines.filter {
            it.height >= best.height * 0.65 && kotlin.math.abs(it.top - best.top) <= best.height * 2.2
        }.sortedBy { it.top }
        out += group.joinToString(" ") { it.text }
        // запасные: отдельные крупные строки
        sorted.take(5).forEach { out += it.text }
        return out.take(4)
    }

    private fun decode(context: Context, uri: Uri): Bitmap? {
        val maxSide = 2000
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        var sample = 1
        while (opts.outWidth / sample > maxSide || opts.outHeight / sample > maxSide) sample *= 2
        val bmp = context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return null
        val rotation = runCatching {
            context.contentResolver.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        }.getOrDefault(0f)
        if (rotation == 0f) return bmp
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rotation) }, true)
    }
}
