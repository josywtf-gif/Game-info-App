package com.gameinfo.app

import android.annotation.SuppressLint
import android.view.ViewGroup
import android.widget.FrameLayout
import kotlinx.coroutines.withTimeoutOrNull
import android.content.Context
import android.net.Uri
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONTokener
import kotlin.coroutines.resume

/**
 * Невидимо (WebView не показывается на экране) открывает Google «Режим ИИ» и забирает текст ответа.
 * Это неофициальный способ: Google может показать капчу/согласие или поменять страницу.
 */
object GoogleAiScraper {

    private const val UA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

    private val junk = setOf(
        "все", "картинки", "видео", "новости", "покупки", "ещё", "еще", "войти", "режим ии", "ai mode",
        "all", "images", "videos", "news", "more", "sign in", "google", "поиск", "фильтры и темы",
        "хорошо", "плохо", "полезно", "скопировать", "поделиться"
    )
    private val stopMarkers = listOf("задать вопрос", "спросите", "ask anything", "ask a follow", "уточните")

    class Blocked(msg: String) : RuntimeException(msg)

    @SuppressLint("SetJavaScriptEnabled")
    suspend fun ask(context: Context, game: String): String? = withContext(Dispatchers.Main) {
        // WebView, прикреплённый к окну (но полностью прозрачный), работает надёжнее отсоединённого
        val host = GameRepository.hostActivity?.get()
        val wv = WebView(host ?: context.applicationContext)
        var root: ViewGroup? = null
        try {
            wv.settings.javaScriptEnabled = true
            wv.settings.domStorageEnabled = true
            wv.settings.userAgentString = UA
            if (host != null) {
                wv.alpha = 0f
                wv.isFocusable = false
                wv.isFocusableInTouchMode = false
                root = host.window.decorView as ViewGroup
                root.addView(wv, 0, FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            } else {
                wv.measure(
                    View.MeasureSpec.makeMeasureSpec(1080, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(1920, View.MeasureSpec.EXACTLY)
                )
                wv.layout(0, 0, 1080, 1920)
            }

            val cm = CookieManager.getInstance()
            cm.setAcceptCookie(true)
            cm.setCookie("https://www.google.com", "CONSENT=YES+cb; Path=/; Domain=.google.com")
            cm.setCookie("https://www.google.com", "SOCS=CAESHAgBEhJnd3NfMjAyMzA4MTAtMF9SQzIaAmVuIAEaBgiAo_CmBg; Path=/; Domain=.google.com")

            val prompt = "Видеоигра для PlayStation или Xbox: \"$game\" (возможны опечатки). " +
                    "Ответь на русском строго в таком формате, каждое поле с новой строки, начинается с метки:\n" +
                    "НАЗВАНИЕ: официальное название\nПЛАТФОРМЫ: через запятую\nЖАНР: ...\nГОД: год выхода\n" +
                    "ЯЗЫКИ: языки интерфейса, субтитров и озвучки, отметь есть ли русский\n" +
                    "ОПИСАНИЕ: 2-3 предложения о чём игра\n" +
                    "ГЕЙМПЛЕЙ: что нужно делать в игре, 3-5 коротких предложений\n" +
                    "СЮЖЕТ: завязка без спойлеров, 2-3 предложения\n" +
                    "СОВЕТЫ: 2-3 совета новичку\nНичего лишнего кроме этих полей."
            val url = "https://www.google.com/search?udm=50&hl=ru&q=" + Uri.encode(prompt)
            wv.loadUrl(url)

            var last = ""
            var stable = 0
            for (sec in 1..45) {
                delay(1000)
                val u = wv.url.orEmpty()
                if (u.contains("/sorry/") || u.contains("consent.google")) {
                    throw Blocked("Google показал проверку (капчу/согласие), открыть режим ИИ не удалось")
                }
                val text = eval(wv, "document.body ? document.body.innerText : ''")
                if (text.contains("unusual traffic") || text.contains("необычный трафик")) {
                    throw Blocked("Google заблокировал автоматический запрос (необычный трафик)")
                }
                if (text.length > 300 && text == last) stable++ else stable = 0
                last = text
                if (sec >= 5 && stable >= 3) break
            }
            clean(last) ?: throw Blocked(
                "Google не вернул ответ. Страница: ${wv.url.orEmpty().take(80)}. " +
                        "Текст: " + last.replace('\n', ' ').take(160).ifBlank { "(пусто)" }
            )
        } finally {
            runCatching { wv.stopLoading(); root?.removeView(wv); wv.destroy() }
        }
    }

    private suspend fun eval(wv: WebView, js: String): String =
        withTimeoutOrNull(3000) {
            suspendCancellableCoroutine<String> { cont ->
                wv.evaluateJavascript(js) { raw ->
                    val v = runCatching { JSONTokener(raw).nextValue() as? String }.getOrNull().orEmpty()
                    if (cont.isActive) cont.resume(v)
                }
            }
        } ?: ""

    private fun clean(text: String): String? {
        val out = ArrayList<String>()
        for (l in text.lines()) {
            val t = l.trim()
            if (t.length < 2 || t.lowercase() in junk) continue
            if (stopMarkers.any { t.lowercase().startsWith(it) }) break
            out += t
        }
        // убираем шапку до первого содержательного абзаца
        val firstLabel = out.indexOfFirst { val u = it.uppercase().replace("*", "").trim(); u.startsWith("НАЗВАНИЕ") || u.startsWith("ПЛАТФОРМЫ") }
        val firstReal = if (firstLabel >= 0) firstLabel else out.indexOfFirst { it.length > 60 }
        val body = (if (firstReal > 0) out.drop(firstReal) else out).joinToString("\n")
        return body.take(3500).takeIf { it.length > 150 }
    }
}
