package com.gameinfo.app

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {

    var query by mutableStateOf("")
    var loading by mutableStateOf(false)
    var result by mutableStateOf<GameInfo?>(null)
    var message by mutableStateOf<String?>(null)
    var suggestions by mutableStateOf<List<String>>(emptyList())

    var update by mutableStateOf<UpdateInfo?>(null)
    var updateProgress by mutableStateOf<Int?>(null)
    var updateMessage by mutableStateOf<String?>(null)

    private var searchJob: Job? = null

    init {
        Updater.cleanup(app)
        checkUpdate(silent = true)
    }

    fun search(q: String = query) {
        val text = q.trim()
        if (text.isEmpty()) return
        query = text
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            loading = true
            message = null
            result = null
            val r = runCatching { GameRepository.find(text) }
            loading = false
            val info = r.getOrNull()
            if (info != null) result = info
            else message = if (r.isFailure) "Нет связи с сервером. Проверьте интернет."
            else "Игра «$text» не найдена. Попробуйте уточнить название." +
                (GameRepository.lastError?.let { "\n\nПричина: $it" } ?: "")
        }
    }

    fun onPhoto(uri: Uri) {
        viewModelScope.launch {
            loading = true
            message = null
            result = null
            suggestions = emptyList()
            val titles = runCatching { TitleExtractor.extract(getApplication(), uri) }.getOrDefault(emptyList())
            if (titles.isEmpty()) {
                loading = false
                message = "Не удалось распознать название на фото. Сфотографируйте обложку крупнее или введите название вручную."
            } else {
                suggestions = titles
                search(titles.first())
            }
        }
    }

    fun checkUpdate(silent: Boolean = false) {
        viewModelScope.launch {
            val r = runCatching { Updater.check() }
            update = r.getOrNull()
            if (!silent) {
                updateMessage = when {
                    r.isFailure -> "Не удалось проверить обновления"
                    update == null -> "У вас последняя версия"
                    else -> null
                }
            }
        }
    }

    fun installUpdate() {
        val u = update ?: return
        viewModelScope.launch {
            updateProgress = 0
            updateMessage = null
            val r = runCatching {
                val apk = Updater.download(getApplication(), u) { updateProgress = it }
                Updater.install(getApplication(), apk)
            }
            updateProgress = null
            if (r.isFailure) updateMessage = "Ошибка загрузки обновления"
            else if (r.getOrNull() == false) updateMessage = "Разрешите установку из этого приложения и нажмите «Обновить» ещё раз"
        }
    }
}
