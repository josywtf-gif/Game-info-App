package com.gameinfo.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import java.io.File

private val Scheme = darkColorScheme(
    primary = Color(0xFF8CA2FF),
    onPrimary = Color(0xFF0B1240),
    background = Color(0xFF0F1020),
    onBackground = Color(0xFFE6E7F5),
    surface = Color(0xFF191B33),
    onSurface = Color(0xFFE6E7F5),
    surfaceVariant = Color(0xFF23264A),
    onSurfaceVariant = Color(0xFFB9BCDF),
    secondaryContainer = Color(0xFF2B3A8F),
    onSecondaryContainer = Color.White,
)

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = Scheme) {
                Screen(vm)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun Screen(vm: MainViewModel) {
    val context = LocalContext.current

    val photoFile = remember { File(context.cacheDir, "photos").apply { mkdirs() }.let { File(it, "disc.jpg") } }
    val photoUri = remember {
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", photoFile)
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) vm.onPhoto(photoUri)
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 12.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Game Info",
                fontSize = 26.sp,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.weight(1f)
            )
            Text(
                "v${BuildConfig.VERSION_NAME}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            TextButton(onClick = { vm.checkUpdate() }) { Text("Обновить") }
        }

        UpdateBanner(vm)

        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = vm.query,
                onValueChange = { vm.query = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Название игры PS / Xbox") },
                shape = RoundedCornerShape(16.dp),
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = {
                    if (vm.query.isNotEmpty()) {
                        IconButton(onClick = { vm.query = "" }) { Icon(Icons.Default.Clear, "Очистить") }
                    }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.search() }),
            )
            Spacer(Modifier.size(8.dp))
            FilledIconButton(
                onClick = { camera.launch(photoUri) },
                modifier = Modifier.size(56.dp),
                shape = RoundedCornerShape(16.dp),
            ) {
                Icon(painterResource(R.drawable.ic_camera), "Сфотографировать диск")
            }
        }

        if (vm.suggestions.size > 1) {
            Column(Modifier.padding(top = 4.dp)) {
                Text("Распознано, нажмите чтобы уточнить:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                vm.suggestions.forEach { s ->
                    AssistChip(
                        onClick = { vm.search(s) },
                        label = { Text(s, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }

        Box(Modifier.fillMaxSize().padding(top = 12.dp)) {
            when {
                vm.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                vm.result != null -> Result(vm.result!!)
                vm.message != null -> Text(
                    vm.message!!,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(8.dp)
                )
                else -> Text(
                    "Введите название игры или сфотографируйте диск — приложение найдёт описание, суть геймплея и сюжет.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(8.dp)
                )
            }
        }
    }
}

@Composable
private fun UpdateBanner(vm: MainViewModel) {
    val u = vm.update
    val progress = vm.updateProgress
    if (u != null) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 10.dp)
        ) {
            Column(Modifier.padding(12.dp)) {
                Text("Доступна новая версия (сборка ${u.build})", color = Color.White)
                if (progress != null) {
                    LinearProgressIndicator(
                        progress = { progress / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                    )
                    Text("Загрузка $progress%", fontSize = 12.sp, color = Color.White)
                } else {
                    Button(onClick = { vm.installUpdate() }, modifier = Modifier.padding(top = 8.dp)) {
                        Text("Скачать и установить")
                    }
                }
            }
        }
    }
    vm.updateMessage?.let {
        Text(
            it,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 8.dp)
        )
    }
}

@Composable
private fun Result(g: GameInfo) {
    val context = LocalContext.current
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (g.imageUrl != null) {
            AsyncImage(
                model = g.imageUrl,
                contentDescription = g.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(16.dp))
            )
        }
        Text(g.title, fontSize = 24.sp, color = MaterialTheme.colorScheme.onBackground)
        Facts(g)
        Section("Описание", g.intro)
        g.gameplay?.let { Section("Что делать (геймплей)", it) }
        g.plot?.let { Section("Сюжет", it) }
        g.languages?.let { Section("Доступные языки", it) }
        g.tips?.let { Section("Советы новичку", it) }
        if (g.pageUrl != null) {
            TextButton(onClick = {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(g.pageUrl)))
            }) { Text("Читать полностью в Википедии") }
        }
        Text("Источник: ${g.source}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Section(title: String, body: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            Text(body, color = MaterialTheme.colorScheme.onSurface, fontSize = 15.sp, lineHeight = 21.sp)
        }
    }
}

@Composable
private fun Facts(g: GameInfo) {
    val rows = listOfNotNull(
        g.platforms?.let { "Платформы" to it },
        g.genre?.let { "Жанр" to it },
        g.year?.let { "Год выхода" to it },
    )
    if (rows.isEmpty()) return
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            rows.forEach { (k, v) ->
                Row {
                    Text(k, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(0.38f))
                    Text(v, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(0.62f))
                }
            }
        }
    }
}
