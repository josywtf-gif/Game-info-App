package com.gameinfo.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class UpdateInfo(val build: Int, val name: String, val apkUrl: String, val notes: String)

object Updater {

    private fun updatesDir(context: Context) = File(context.cacheDir, "updates")

    /** Удаляет скачанные APK и временные фото. Вызывается при старте и после установки новой версии. */
    fun cleanup(context: Context) {
        runCatching { updatesDir(context).deleteRecursively() }
        runCatching { File(context.cacheDir, "photos").deleteRecursively() }
    }

    /** Ищет последний релиз в GitHub Releases; тег вида build-N, N — номер сборки. */
    suspend fun check(): UpdateInfo? = withContext(Dispatchers.IO) {
        val repo = BuildConfig.UPDATE_REPO
        if (repo.isBlank()) return@withContext null
        val c = URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 15_000
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("User-Agent", "GameInfoApp")
        try {
            if (c.responseCode != 200) return@withContext null
            val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val build = j.getString("tag_name").substringAfterLast('-').toIntOrNull() ?: return@withContext null
            if (build <= BuildConfig.VERSION_CODE) return@withContext null
            val assets = j.getJSONArray("assets")
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.getString("name").endsWith(".apk")) {
                    return@withContext UpdateInfo(
                        build = build,
                        name = j.optString("name", "build $build"),
                        apkUrl = a.getString("browser_download_url"),
                        notes = j.optString("body", ""),
                    )
                }
            }
            null
        } finally {
            c.disconnect()
        }
    }

    suspend fun download(context: Context, info: UpdateInfo, onProgress: (Int) -> Unit): File =
        withContext(Dispatchers.IO) {
            val dir = updatesDir(context).apply { deleteRecursively(); mkdirs() }
            val out = File(dir, "GameInfo-${info.build}.apk")
            val c = URL(info.apkUrl).openConnection() as HttpURLConnection
            c.connectTimeout = 15_000
            c.readTimeout = 30_000
            c.setRequestProperty("User-Agent", "GameInfoApp")
            try {
                val total = c.contentLengthLong
                var done = 0L
                var last = -1
                c.inputStream.use { input ->
                    out.outputStream().use { o ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            o.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val p = (done * 100 / total).toInt()
                                if (p != last) { last = p; onProgress(p) }
                            }
                        }
                    }
                }
            } finally {
                c.disconnect()
            }
            out
        }

    /** Запускает системный установщик. false — нужно сначала разрешить установку из этого приложения. */
    fun install(context: Context, apk: File): Boolean {
        if (!context.packageManager.canRequestPackageInstalls()) {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return false
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", apk)
        context.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return true
    }
}
