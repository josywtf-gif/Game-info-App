package com.gameinfo.app

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class GameInfo(
    val title: String,
    val intro: String,
    val gameplay: String?,
    val plot: String?,
    val imageUrl: String?,
    val pageUrl: String?,
    val lang: String,
    val platforms: String? = null,
    val genre: String? = null,
    val year: String? = null,
    val tips: String? = null,
    val source: String = "Википедия",
)

object GameRepository {

    private const val GEMINI_MODEL = "gemini-2.5-flash"
    private val gameplayHeads = listOf("игровой процесс", "геймплей", "gameplay")
    private val plotHeads = listOf("сюжет", "plot", "synopsis", "story", "premise")
    private val gameWords = listOf("игр", "game", "videogame")

    /** Ищет игру в русской, затем в английской Википедии. */
    suspend fun find(query: String): GameInfo? = withContext(Dispatchers.IO) {
        val q = query.trim()
        if (q.isEmpty()) return@withContext null
        if (BuildConfig.GEMINI_KEY.isNotBlank()) {
            val ai = runCatching { askGemini(q) }.getOrNull()
            if (ai != null) return@withContext ai
        }
        for ((lang, suffix) in listOf("ru" to "видеоигра", "en" to "video game")) {
            val r = runCatching { search(lang, q, suffix) }.getOrNull()
            if (r != null) return@withContext r
        }
        null
    }

    /** Запрос к Google Gemini (без WebView, обычный HTTPS-запрос). */
    private fun askGemini(q: String): GameInfo? {
        val str = JSONObject().put("type", "STRING")
        val props = JSONObject()
            .put("found", JSONObject().put("type", "BOOLEAN"))
            .put("title", str).put("platforms", str).put("genre", str).put("year", str)
            .put("description", str).put("gameplay", str).put("plot", str).put("tips", str)
        val schema = JSONObject().put("type", "OBJECT").put("properties", props)
            .put("required", org.json.JSONArray(listOf("found")))
        val prompt = "Пользователь ищет видеоигру для PlayStation или Xbox. Запрос (может быть с опечатками " +
                "или быть текстом, распознанным с обложки диска): \"$q\".\n" +
                "Определи игру. Если такой игры нет или ты не уверен, верни found=false.\n" +
                "Ответ на русском языке, коротко и по делу: title — официальное название; platforms — платформы; " +
                "genre — жанр; year — год выхода; description — 2-3 предложения о чём игра; " +
                "gameplay — что в игре нужно делать, 3-5 коротких предложений; plot — завязка сюжета без спойлеров, " +
                "2-3 предложения (пусто, если сюжета нет); tips — 2-3 совета новичку."
        val body = JSONObject()
            .put("contents", org.json.JSONArray().put(JSONObject().put("parts",
                org.json.JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject()
                .put("responseMimeType", "application/json")
                .put("responseSchema", schema)
                .put("temperature", 0.2))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$GEMINI_MODEL:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 10_000
        c.readTimeout = 30_000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", BuildConfig.GEMINI_KEY)
        try {
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            if (c.responseCode != 200) return null
            val resp = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val text = resp.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            val j = JSONObject(text)
            if (!j.optBoolean("found", false)) return null
            fun f(k: String) = j.optString(k).trim().takeIf { it.isNotEmpty() && it != "null" }
            val desc = f("description") ?: return null
            return GameInfo(
                title = f("title") ?: q,
                intro = desc,
                gameplay = f("gameplay"),
                plot = f("plot"),
                imageUrl = null,
                pageUrl = null,
                lang = "ru",
                platforms = f("platforms"),
                genre = f("genre"),
                year = f("year"),
                tips = f("tips"),
                source = "Google Gemini",
            )
        } finally {
            c.disconnect()
        }
    }

    private fun search(lang: String, q: String, suffix: String): GameInfo? {
        val base = "https://$lang.wikipedia.org/w/api.php"
        val s = get("$base?action=query&list=search&srlimit=5&format=json&srsearch=" +
                Uri.encode("$q $suffix"))
        val hits = JSONObject(s).getJSONObject("query").getJSONArray("search")
        for (i in 0 until hits.length()) {
            val title = hits.getJSONObject(i).getString("title")
            val info = page(lang, title) ?: continue
            return info
        }
        return null
    }

    private fun page(lang: String, title: String): GameInfo? {
        val base = "https://$lang.wikipedia.org/w/api.php"
        val body = get(
            "$base?action=query&format=json&redirects=1&prop=extracts|pageimages" +
                    "&explaintext=1&exsectionformat=wiki&piprop=thumbnail&pithumbsize=700" +
                    "&titles=" + Uri.encode(title)
        )
        val pages = JSONObject(body).getJSONObject("query").getJSONObject("pages")
        val key = pages.keys().next()
        if (key == "-1") return null
        val p = pages.getJSONObject(key)
        val text = p.optString("extract")
        if (text.isBlank()) return null

        val headRe = Regex("^==+\\s*(.+?)\\s*==+\\s*$", RegexOption.MULTILINE)
        val matches = headRe.findAll(text).toList()
        val intro = (if (matches.isEmpty()) text else text.substring(0, matches.first().range.first)).trim()

        // это должна быть статья про игру
        val low = intro.lowercase()
        if (gameWords.none { low.contains(it) }) return null

        fun section(names: List<String>): String? {
            for ((idx, m) in matches.withIndex()) {
                val name = m.groupValues[1].lowercase()
                if (names.any { name.contains(it) }) {
                    val end = matches.getOrNull(idx + 1)?.range?.first ?: text.length
                    val body2 = text.substring(m.range.last + 1, end).trim()
                    if (body2.length > 80) return body2
                }
            }
            return null
        }

        val realTitle = p.optString("title", title)
        return GameInfo(
            title = realTitle,
            intro = cut(intro, 800),
            gameplay = section(gameplayHeads)?.let { cut(it, 1100) },
            plot = section(plotHeads)?.let { cut(it, 700) },
            imageUrl = p.optJSONObject("thumbnail")?.optString("source"),
            pageUrl = "https://$lang.wikipedia.org/wiki/" + Uri.encode(realTitle.replace(' ', '_')),
            lang = lang,
        )
    }

    private fun cut(s: String, max: Int): String {
        val t = s.replace(Regex("\n{3,}"), "\n\n").trim()
        if (t.length <= max) return t
        val part = t.substring(0, max)
        val end = maxOf(part.lastIndexOf(". "), part.lastIndexOf("! "), part.lastIndexOf("? "))
        return if (end > max / 2) part.substring(0, end + 1) else part.trimEnd() + "…"
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 15_000
        c.setRequestProperty("User-Agent", "GameInfoApp/1.0 (Android)")
        return try {
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}
