package com.gameinfo.app

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class GameInfo(
    val title: String,
    val intro: String,
    val gameplay: String?,
    val plot: String?,
    val imageUrl: String?,
    val pageUrl: String?,
    val lang: String,
    val platforms: String? = null,
    val genre: String? = null,
    val year: String? = null,
    val tips: String? = null,
    val languages: String? = null,
    val source: String = "Википедия",
)

object GameRepository {

    /** Задаётся при старте (нужен WebView для режима ИИ Google). */
    @Volatile var appContext: android.content.Context? = null
    @Volatile var hostActivity: java.lang.ref.WeakReference<android.app.Activity>? = null

    // Если Google снимет модель с доступа (ошибка 404), пробуется следующая из списка
    private val GEMINI_MODELS = listOf("gemini-3.8-flash", "gemini-flash-latest")
    private val gameplayHeads = listOf("игровой процесс", "геймплей", "gameplay")
    private val plotHeads = listOf("сюжет", "plot", "synopsis", "story", "premise")
    private val gameWords = listOf("игр", "game", "videogame")

    /** Причина последней неудачи Gemini (для показа на экране). */
    private val errs = java.util.concurrent.CopyOnWriteArrayList<String>()

    /** Присваивание null очищает, любое другое значение добавляется к списку причин. */
    var lastError: String?
        get() = errs.joinToString("\n\n").ifEmpty { null }
        set(v) { if (v == null) errs.clear() else errs.add(v) }

    /** Сначала Google Gemini (с поиском Google), затем запасной вариант — Википедия. */
    suspend fun find(query: String): GameInfo? = withContext(Dispatchers.IO) {
        val q = query.trim()
        if (q.isEmpty()) return@withContext null
        lastError = null
        // 1) Google «Режим ИИ» в невидимом WebView
        appContext?.let { ctx ->
            try {
                val text = kotlinx.coroutines.withTimeout(60_000) { GoogleAiScraper.ask(ctx, q) }
                if (text != null) {
                    val info = parseSections(text, q, "Google · Режим ИИ")
                    if (info != null) return@withContext info
                }
                lastError = "Google (режим ИИ) не вернул ответ"
            } catch (e: Exception) {
                lastError = if (e is kotlinx.coroutines.TimeoutCancellationException)
                    "Google: превышено время ожидания (60 с)" else (e.message ?: e.javaClass.simpleName)
            }
        }
        // 2) Gemini API (если в сборке есть ключ)
        if (BuildConfig.GEMINI_KEY.isBlank()) {
            lastError = "в сборку не попал ключ GEMINI_KEY (проверьте секрет в GitHub и пересоберите)"
        } else {
            try {
                val ai = askGemini(q)
                if (ai != null) return@withContext ai
                lastError = "Gemini не нашёл такую игру"
            } catch (e: Exception) {
                lastError = e.message ?: e.javaClass.simpleName
            }
        }
        for ((lang, suffix) in listOf("ru" to "видеоигра", "en" to "video game")) {
            val r = runCatching { search(lang, q, suffix) }.getOrNull()
            if (r != null) return@withContext r
        }
        null
    }

    /** Метки в ответе ИИ -> поле. Допускаются синонимы и markdown-оформление. */
    private val labelMap = linkedMapOf(
        "НАЗВАНИЕ" to "title", "ИГРА" to "title",
        "ПЛАТФОРМЫ" to "platforms", "ПЛАТФОРМА" to "platforms",
        "ЖАНР" to "genre", "ЖАНРЫ" to "genre",
        "ГОД ВЫХОДА" to "year", "ГОД" to "year", "ДАТА ВЫХОДА" to "year",
        "ЯЗЫКИ" to "languages", "ЯЗЫК" to "languages", "ЛОКАЛИЗАЦИЯ" to "languages",
        "ЯЗЫКИ ИНТЕРФЕЙСА И ОЗВУЧКИ" to "languages", "ОЗВУЧКА" to "languages",
        "ОПИСАНИЕ" to "description", "О ИГРЕ" to "description", "О ЧЁМ ИГРА" to "description",
        "О ЧЕМ ИГРА" to "description",
        "ГЕЙМПЛЕЙ" to "gameplay", "ИГРОВОЙ ПРОЦЕСС" to "gameplay", "ЧТО ДЕЛАТЬ" to "gameplay",
        "ЧТО ДЕЛАТЬ В ИГРЕ" to "gameplay",
        "СЮЖЕТ" to "plot", "СОВЕТЫ" to "tips", "СОВЕТЫ НОВИЧКУ" to "tips",
    )

    /** Раскладывает текст ответа ИИ по полям: платформы, жанр, год, языки, описание, геймплей, сюжет, советы. */
    fun parseSections(raw: String, q: String, source: String): GameInfo? {
        val text = raw.replace(Regex("[*#`]"), "").replace(Regex("(?m)^\\s*[-•·]\\s+(?=[А-ЯЁA-Z ]{2,40}\\s*[:—])"), "")
        val names = labelMap.keys.sortedByDescending { it.length }.joinToString("|") { Regex.escape(it) }
        val re = Regex("^\\s*($names)\\s*(?::|—|–)\\s*", setOf(RegexOption.MULTILINE, RegexOption.IGNORE_CASE))
        val found = re.findAll(text).toList()
        val map = HashMap<String, String>()
        for ((i, m) in found.withIndex()) {
            val end = found.getOrNull(i + 1)?.range?.first ?: text.length
            val key = labelMap[m.groupValues[1].uppercase()] ?: continue
            val v = text.substring(m.range.last + 1, end).trim()
            if (v.isNotEmpty() && !map.containsKey(key)) map[key] = v
        }
        fun f(k: String) = map[k]?.takeIf { it.isNotBlank() }
        // Если метки не распознаны — показываем весь текст как описание
        val desc = f("description") ?: if (found.isEmpty()) text.trim() else return null
        if (desc.length < 20) return null
        return GameInfo(
            title = f("title")?.lines()?.first()?.trim() ?: q.replaceFirstChar { it.uppercase() },
            intro = desc,
            gameplay = f("gameplay"),
            plot = f("plot"),
            imageUrl = null,
            pageUrl = null,
            lang = "ru",
            platforms = f("platforms")?.lines()?.joinToString(", ") { it.trim().trimStart('-', '•').trim() },
            genre = f("genre")?.lines()?.joinToString(", ") { it.trim().trimStart('-', '•').trim() },
            year = f("year")?.lines()?.first()?.trim(),
            tips = f("tips"),
            languages = f("languages"),
            source = source,
        )
    }

    /** Запрос к Google Gemini с поиском Google (обычный HTTPS, без WebView). */
    private fun askGemini(q: String): GameInfo? {
        var last: Exception? = null
        for (m in GEMINI_MODELS) {
            try {
                return askGemini(q, m)
            } catch (e: ModelGone) {
                last = e
            }
        }
        throw last ?: RuntimeException("Gemini: нет доступной модели")
    }

    private class ModelGone(msg: String) : RuntimeException(msg)

    private fun askGemini(q: String, model: String): GameInfo? {
        val prompt = "Пользователь ищет видеоигру для PlayStation или Xbox. Запрос: \"$q\" " +
                "(возможны опечатки, а также текст, распознанный с обложки диска; игра может быть совсем новой, " +
                "2025-2026 годов — найди её через поиск Google).\n" +
                "Определи игру, исправив опечатки. Если игры действительно нет, ответь одним словом: НЕТ.\n" +
                "Иначе ответь на русском строго в таком формате, каждое поле начинается с метки в начале строки:\n" +
                "НАЗВАНИЕ: официальное название\nПЛАТФОРМЫ: ...\nЖАНР: ...\nГОД: год выхода\nЯЗЫКИ: языки интерфейса, субтитров и озвучки (отметь, есть ли русский)\n" +
                "ОПИСАНИЕ: 2-3 предложения о чём игра\n" +
                "ГЕЙМПЛЕЙ: что в игре нужно делать, 3-5 коротких предложений\n" +
                "СЮЖЕТ: завязка без спойлеров, 2-3 предложения (если сюжета нет — пропусти поле)\n" +
                "СОВЕТЫ: 2-3 совета новичку\nБез markdown и без ссылок."
        val body = JSONObject()
            .put("contents", org.json.JSONArray().put(JSONObject().put("parts",
                org.json.JSONArray().put(JSONObject().put("text", prompt)))))
            .put("tools", org.json.JSONArray().put(JSONObject().put("google_search", JSONObject())))
            .put("generationConfig", JSONObject().put("temperature", 0.2))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 10_000
        c.readTimeout = 45_000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", BuildConfig.GEMINI_KEY)
        try {
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            if (c.responseCode != 200) {
                val err = c.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                val msg = runCatching { JSONObject(err).getJSONObject("error").getString("message") }
                    .getOrDefault(err).take(200)
                if (c.responseCode == 404) throw ModelGone("Gemini 404 ($model): $msg")
                throw RuntimeException("Gemini ${c.responseCode}: $msg")
            }
            val resp = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val parts = resp.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val text = buildString {
                for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text"))
            }.replace("**", "").trim()
            if (text.isBlank() || text.trim().trimEnd('.').uppercase() == "НЕТ") return null

            return parseSections(text, q, "Google Gemini + поиск Google")
        } finally {
            c.disconnect()
        }
    }

    private fun search(lang: String, q: String, suffix: String): GameInfo? {
        val base = "https://$lang.wikipedia.org/w/api.php"
        val s = get("$base?action=query&list=search&srlimit=5&format=json&srsearch=" +
                Uri.encode("$q $suffix"))
        val hits = JSONObject(s).getJSONObject("query").getJSONArray("search")
        for (i in 0 until hits.length()) {
            val title = hits.getJSONObject(i).getString("title")
            val info = page(lang, title) ?: continue
            return info
        }
        return null
    }

    private fun page(lang: String, title: String): GameInfo? {
        val base = "https://$lang.wikipedia.org/w/api.php"
        val body = get(
            "$base?action=query&format=json&redirects=1&prop=extracts|pageimages" +
                    "&explaintext=1&exsectionformat=wiki&piprop=thumbnail&pithumbsize=700" +
                    "&titles=" + Uri.encode(title)
        )
        val pages = JSONObject(body).getJSONObject("query").getJSONObject("pages")
        val key = pages.keys().next()
        if (key == "-1") return null
        val p = pages.getJSONObject(key)
        val text = p.optString("extract")
        if (text.isBlank()) return null

        val headRe = Regex("^==+\\s*(.+?)\\s*==+\\s*$", RegexOption.MULTILINE)
        val matches = headRe.findAll(text).toList()
        val intro = (if (matches.isEmpty()) text else text.substring(0, matches.first().range.first)).trim()

        // это должна быть статья про игру
        val low = intro.lowercase()
        if (gameWords.none { low.contains(it) }) return null

        fun section(names: List<String>): String? {
            for ((idx, m) in matches.withIndex()) {
                val name = m.groupValues[1].lowercase()
                if (names.any { name.contains(it) }) {
                    val end = matches.getOrNull(idx + 1)?.range?.first ?: text.length
                    val body2 = text.substring(m.range.last + 1, end).trim()
                    if (body2.length > 80) return body2
                }
            }
            return null
        }

        val realTitle = p.optString("title", title)
        return GameInfo(
            title = realTitle,
            intro = cut(intro, 800),
            gameplay = section(gameplayHeads)?.let { cut(it, 1100) },
            plot = section(plotHeads)?.let { cut(it, 700) },
            imageUrl = p.optJSONObject("thumbnail")?.optString("source"),
            pageUrl = "https://$lang.wikipedia.org/wiki/" + Uri.encode(realTitle.replace(' ', '_')),
            lang = lang,
        )
    }

    private fun cut(s: String, max: Int): String {
        val t = s.replace(Regex("\n{3,}"), "\n\n").trim()
        if (t.length <= max) return t
        val part = t.substring(0, max)
        val end = maxOf(part.lastIndexOf(". "), part.lastIndexOf("! "), part.lastIndexOf("? "))
        return if (end > max / 2) part.substring(0, end + 1) else part.trimEnd() + "…"
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 15_000
        c.setRequestProperty("User-Agent", "GameInfoApp/1.0 (Android)")
        return try {
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}
