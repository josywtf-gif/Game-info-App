package com.gameinfo.app

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class GameInfo(
    val title: String,
    val intro: String,
    val gameplay: String?,
    val plot: String?,
    val imageUrl: String?,
    val pageUrl: String,
    val lang: String,
)

object GameRepository {

    private val gameplayHeads = listOf("игровой процесс", "геймплей", "gameplay")
    private val plotHeads = listOf("сюжет", "plot", "synopsis", "story", "premise")
    private val gameWords = listOf("игр", "game", "videogame")

    /** Ищет игру в русской, затем в английской Википедии. */
    suspend fun find(query: String): GameInfo? = withContext(Dispatchers.IO) {
        val q = query.trim()
        if (q.isEmpty()) return@withContext null
        for ((lang, suffix) in listOf("ru" to "видеоигра", "en" to "video game")) {
            val r = runCatching { search(lang, q, suffix) }.getOrNull()
            if (r != null) return@withContext r
        }
        null
    }

    private fun search(lang: String, q: String, suffix: String): GameInfo? {
        val base = "https://$lang.wikipedia.org/w/api.php"
        val s = get("$base?action=query&list=search&srlimit=5&format=json&srsearch=" +
                Uri.encode("$q $suffix"))
        val hits = JSONObject(s).getJSONObject("query").getJSONArray("search")
        for (i in 0 until hits.length()) {
            val title = hits.getJSONObject(i).getString("title")
            val info = page(lang, title) ?: continue
            return info
        }
        return null
    }

    private fun page(lang: String, title: String): GameInfo? {
        val base = "https://$lang.wikipedia.org/w/api.php"
        val body = get(
            "$base?action=query&format=json&redirects=1&prop=extracts|pageimages" +
                    "&explaintext=1&exsectionformat=wiki&piprop=thumbnail&pithumbsize=700" +
                    "&titles=" + Uri.encode(title)
        )
        val pages = JSONObject(body).getJSONObject("query").getJSONObject("pages")
        val key = pages.keys().next()
        if (key == "-1") return null
        val p = pages.getJSONObject(key)
        val text = p.optString("extract")
        if (text.isBlank()) return null

        val headRe = Regex("^==+\\s*(.+?)\\s*==+\\s*$", RegexOption.MULTILINE)
        val matches = headRe.findAll(text).toList()
        val intro = (if (matches.isEmpty()) text else text.substring(0, matches.first().range.first)).trim()

        // это должна быть статья про игру
        val low = intro.lowercase()
        if (gameWords.none { low.contains(it) }) return null

        fun section(names: List<String>): String? {
            for ((idx, m) in matches.withIndex()) {
                val name = m.groupValues[1].lowercase()
                if (names.any { name.contains(it) }) {
                    val end = matches.getOrNull(idx + 1)?.range?.first ?: text.length
                    val body2 = text.substring(m.range.last + 1, end).trim()
                    if (body2.length > 80) return body2
                }
            }
            return null
        }

        val realTitle = p.optString("title", title)
        return GameInfo(
            title = realTitle,
            intro = cut(intro, 800),
            gameplay = section(gameplayHeads)?.let { cut(it, 1100) },
            plot = section(plotHeads)?.let { cut(it, 700) },
            imageUrl = p.optJSONObject("thumbnail")?.optString("source"),
            pageUrl = "https://$lang.wikipedia.org/wiki/" + Uri.encode(realTitle.replace(' ', '_')),
            lang = lang,
        )
    }

    private fun cut(s: String, max: Int): String {
        val t = s.replace(Regex("\n{3,}"), "\n\n").trim()
        if (t.length <= max) return t
        val part = t.substring(0, max)
        val end = maxOf(part.lastIndexOf(". "), part.lastIndexOf("! "), part.lastIndexOf("? "))
        return if (end > max / 2) part.substring(0, end + 1) else part.trimEnd() + "…"
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 15_000
        c.setRequestProperty("User-Agent", "GameInfoApp/1.0 (Android)")
        return try {
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}
