package com.gameinfo.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** После установки новой версии поверх старой удаляет скачанный APK. */
class PackageReplacedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Updater.cleanup(context)
    }
}
